# Emberwake for Android

A native Android app (Kotlin) that runs the Emberwake game full screen, offline, in portrait.
Your progress is saved on the phone and offline grinding continues while the app is closed.

## Option A — build on your computer (Android Studio)
1. Install **Android Studio** (free): https://developer.android.com/studio
2. Unzip this folder, then in Android Studio choose **File → Open** and select the `emberwake-android` folder.
   Wait until the bottom bar says the Gradle sync is finished (the first time takes a few minutes).
3. Plug in your phone with a USB cable. On the phone: **Settings → About phone → tap "Build number" 7 times**,
   then **Settings → Developer options → USB debugging: on**.
4. Press the green **▶ Run** button. The game installs and opens on your phone.
   To get an installable file instead: **Build → Build App Bundle(s) / APK(s) → Build APK(s)**, then
   tap "locate" — the file is `app/build/outputs/apk/debug/app-debug.apk`.

## Option B — build in the cloud (no installs, needs a free GitHub account)
1. Create a new repository on github.com and upload the contents of this folder.
2. Open the **Actions** tab → **Build APK** → **Run workflow**.
3. When it finishes (about 5 minutes), open the run and download **Emberwake-apk**.
4. Copy `Emberwake.apk` to your phone and open it. Android asks to allow installs from that app once.

## Updating the game
The whole game is one file: `app/src/main/assets/index.html`. Replace it with a newer version and build again.
Raise `versionCode` in `app/build.gradle.kts` by 1 each time so the phone installs the update over the old one
(your save is kept).

## Publishing on Google Play
The app targets **Android 16 (API level 36)**, which Google Play requires for new apps and updates since 31 August 2026.
It still runs on phones from Android 8.0 upward. Google Play needs an **App Bundle**: Build → Generate Signed App Bundle.

The release build is signed with Android's debug key so it installs right away. Before uploading to
Google Play, create your own signing key in Android Studio (**Build → Generate Signed App Bundle**).
